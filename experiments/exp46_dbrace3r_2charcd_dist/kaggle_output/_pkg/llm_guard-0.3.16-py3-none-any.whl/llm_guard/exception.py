class LLMGuardValidationError(ValueError):
    pass
